import { User, ShippingLabel, Address, Transaction, UserRole } from '../types';

// Initial Mock Data
const MOCK_DELAY = 600;

const getStorage = <T>(key: string, initial: T): T => {
  const stored = localStorage.getItem(key);
  return stored ? JSON.parse(stored) : initial;
};

const setStorage = (key: string, value: any) => {
  localStorage.setItem(key, JSON.stringify(value));
};

// Simulate API call delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// --- Auth Service ---

export const mockLogin = async (email: string, password: string): Promise<{ user: User; token: string }> => {
  await delay(MOCK_DELAY);
  
  if (email === 'demo@example.com' && password === 'password') {
    // Return existing demo user
    let user = getStorage<User>('currentUser', {
      id: 'usr_123',
      email: 'demo@example.com',
      balance: 150.00,
      role: UserRole.USER
    });
    return { user, token: 'mock_jwt_token_123' };
  }
  
  // For new users in this simulation, we just create them on the fly if not "demo"
  // In a real app, this would check the DB.
  if (password.length < 6) throw new Error("Password too short");
  
  const user: User = {
    id: `usr_${Date.now()}`,
    email,
    balance: 0,
    role: UserRole.USER
  };
  setStorage('currentUser', user);
  return { user, token: `mock_jwt_${Date.now()}` };
};

export const mockRegister = async (email: string, password: string): Promise<{ user: User; token: string }> => {
  return mockLogin(email, password); // Simulating same flow for this demo
};

export const mockGetUser = async (): Promise<User | null> => {
  await delay(200);
  return getStorage<User | null>('currentUser', null);
};

// --- Wallet Service ---

export const mockAddFunds = async (amount: number, currency: string): Promise<string> => {
  await delay(MOCK_DELAY);
  // Simulate NowPayments Invoice URL generation
  // In real app: POST /api/payments/invoice -> returns { invoice_url }
  return `https://nowpayments.io/payment/?amount=${amount}&currency=${currency}&order_id=ord_${Date.now()}`;
};

// Simulate Webhook trigger (manually called by frontend for demo purposes)
export const mockVerifyPayment = async (amount: number): Promise<User> => {
  await delay(MOCK_DELAY);
  const user = getStorage<User>('currentUser', { id: '0', email: '', balance: 0, role: UserRole.USER });
  const newBalance = user.balance + amount;
  const updatedUser = { ...user, balance: newBalance };
  
  setStorage('currentUser', updatedUser);
  
  // Record transaction
  const txs = getStorage<Transaction[]>('transactions', []);
  const newTx: Transaction = {
    id: `tx_${Date.now()}`,
    userId: user.id,
    amount,
    currency: 'USDT', // simplified
    status: 'completed',
    date: new Date().toISOString(),
    type: 'deposit'
  };
  setStorage('transactions', [newTx, ...txs]);
  
  return updatedUser;
};

// --- Shipping Service ---

export const mockCreateLabel = async (labelData: { from: Address; to: Address; weight: number; service: string }): Promise<ShippingLabel> => {
  await delay(1500); // Simulate API call to carrier
  
  const user = getStorage<User>('currentUser', { id: '0', email: '', balance: 0, role: UserRole.USER });
  
  // Calculate Cost
  let baseRate = 5.00;
  if (labelData.service === 'priority') baseRate = 8.50;
  if (labelData.service === 'express') baseRate = 25.00;
  const cost = baseRate + (labelData.weight * 0.5);
  
  if (user.balance < cost) {
    throw new Error("Insufficient funds. Please add crypto to your wallet.");
  }
  
  // Deduct funds
  const updatedUser = { ...user, balance: user.balance - cost };
  setStorage('currentUser', updatedUser);
  
  const newLabel: ShippingLabel = {
    id: `lbl_${Date.now()}`,
    userId: user.id,
    from: labelData.from,
    to: labelData.to,
    weight: labelData.weight,
    service: labelData.service as any,
    cost: Number(cost.toFixed(2)),
    trackingNumber: `94001000${Math.floor(Math.random() * 10000000)}`,
    status: 'created',
    createdAt: new Date().toISOString(),
    pdfUrl: '#' // In real app, this is the PDF link
  };
  
  // Save Label History
  const labels = getStorage<ShippingLabel[]>('shipping_labels', []);
  setStorage('shipping_labels', [newLabel, ...labels]);
  
  // Save Used Addresses for Autocomplete
  const usedAddresses = getStorage<Address[]>('used_addresses', []);
  // Simple de-dupe check based on street1
  const exists = usedAddresses.some(a => a.street1 === labelData.to.street1 && a.zip === labelData.to.zip);
  if (!exists) {
    setStorage('used_addresses', [labelData.to, ...usedAddresses]);
  }
  
  return newLabel;
};

export const mockGetHistory = async (): Promise<ShippingLabel[]> => {
  await delay(500);
  return getStorage<ShippingLabel[]>('shipping_labels', []);
};

export const mockGetUsedAddresses = async (): Promise<Address[]> => {
  return getStorage<Address[]>('used_addresses', []);
};

// --- Utils ---

export const getRandomAddress = (): Address => {
  const streets = ['Maple Ave', 'Oak St', 'Main St', 'Broadway', 'Park Ln'];
  const cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix'];
  const states = ['NY', 'CA', 'IL', 'TX', 'AZ'];
  
  const rand = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];
  const randNum = (min: number, max: number) => Math.floor(Math.random() * (max - min) + min);
  
  return {
    name: `John Doe ${randNum(1, 100)}`,
    street1: `${randNum(100, 9999)} ${rand(streets)}`,
    city: rand(cities),
    state: rand(states),
    zip: `${randNum(10000, 99999)}`,
    phone: `555-${randNum(100, 999)}-${randNum(1000, 9999)}`,
    email: `customer${randNum(1, 1000)}@example.com`
  };
};