import React from 'react';
import { Card, Input, Button } from '../components/Components';
import { useAuth } from '../App';

const Settings: React.FC = () => {
  const { user } = useAuth();
  
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Account Settings</h2>
      
      <Card>
        <h3 className="text-lg font-medium text-gray-900 mb-4">Profile Information</h3>
        <div className="space-y-4">
          <Input label="Email Address" value={user?.email || ''} disabled className="bg-gray-50" />
          <Input label="User ID" value={user?.id || ''} disabled className="bg-gray-50" />
        </div>
      </Card>

      <Card>
        <h3 className="text-lg font-medium text-gray-900 mb-4">Security</h3>
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); alert("Password updated successfully!"); }}>
          <Input label="Current Password" type="password" />
          <Input label="New Password" type="password" />
          <Input label="Confirm New Password" type="password" />
          <div className="flex justify-end pt-2">
            <Button type="submit" variant="secondary">Update Password</Button>
          </div>
        </form>
      </Card>
    </div>
  );
};

export default Settings;