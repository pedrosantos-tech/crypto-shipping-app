import React, { useEffect, useState } from 'react';
import { Download, Search, PackageOpen } from 'lucide-react';
import { Card, Input, Button } from '../components/Components';
import { mockGetHistory } from '../services/mockBackend';
import { ShippingLabel } from '../types';

const History: React.FC = () => {
  const [labels, setLabels] = useState<ShippingLabel[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const data = await mockGetHistory();
    setLabels(data);
    setLoading(false);
  };

  const filtered = labels.filter(l => 
    l.trackingNumber.includes(search) || 
    l.to.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <h2 className="text-2xl font-bold text-gray-900">Shipment History</h2>
        <div className="w-full md:w-64 relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          <Input 
            placeholder="Search tracking or name..." 
            className="pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <Card className="p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4">Recipient</th>
                <th className="px-6 py-4">Service</th>
                <th className="px-6 py-4">Tracking</th>
                <th className="px-6 py-4 text-right">Cost</th>
                <th className="px-6 py-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="text-center py-8">Loading history...</td></tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-gray-500">
                    <div className="flex flex-col items-center">
                      <PackageOpen className="w-12 h-12 mb-2 text-gray-300" />
                      No shipments found.
                    </div>
                  </td>
                </tr>
              ) : (
                filtered.map((label) => (
                  <tr key={label.id} className="bg-white border-b hover:bg-gray-50">
                    <td className="px-6 py-4 text-gray-500">
                      {new Date(label.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 font-medium text-gray-900">
                      <div>{label.to.name}</div>
                      <div className="text-xs text-gray-500">{label.to.city}, {label.to.state}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full uppercase font-semibold">
                        {label.service}
                      </span>
                    </td>
                    <td className="px-6 py-4 font-mono text-gray-600">
                      {label.trackingNumber}
                    </td>
                    <td className="px-6 py-4 text-right font-medium">
                      ${label.cost.toFixed(2)}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <Button size="sm" variant="outline" onClick={() => alert(`Downloading PDF for ${label.trackingNumber}...`)}>
                        <Download className="w-4 h-4" />
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default History;