import React, { useState } from 'react';
import { Plus, Wallet, ArrowUpRight, ArrowDownLeft, TrendingUp } from 'lucide-react';
import { Card, Button, Modal, Select, Input } from '../components/Components';
import { useAuth } from '../App';
import { mockAddFunds, mockVerifyPayment } from '../services/mockBackend';

const Dashboard: React.FC = () => {
  const { user, refreshUser } = useAuth();
  const [isDepositModalOpen, setDepositModalOpen] = useState(false);
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('USDT');
  const [loading, setLoading] = useState(false);

  const handleDeposit = async () => {
    setLoading(true);
    try {
      // 1. Get Payment URL (Mock)
      const url = await mockAddFunds(Number(amount), currency);
      
      // 2. In a real app, we redirect. Here we simulate the webhook callback for immediate feedback.
      // Simulating user paying and returning:
      if (confirm(`Redirecting to NowPayments to pay ${amount} ${currency}...\n\n(Click OK to simulate successful payment)`)) {
        await mockVerifyPayment(Number(amount));
        await refreshUser();
        setDepositModalOpen(false);
        setAmount('');
      }
    } catch (error) {
      alert("Payment failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
          <p className="text-gray-500">Welcome back, {user?.email}</p>
        </div>
        <Button onClick={() => setDepositModalOpen(true)} className="shadow-lg shadow-blue-500/20">
          <Plus className="w-4 h-4 mr-2" /> Add Funds
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-br from-primary to-slate-800 text-white border-none">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-white/10 rounded-lg">
              <Wallet className="w-6 h-6 text-blue-300" />
            </div>
            <span className="text-xs font-medium bg-green-500/20 text-green-300 px-2 py-1 rounded-full flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" /> Active
            </span>
          </div>
          <div className="space-y-1">
            <p className="text-slate-400 text-sm font-medium">Total Balance</p>
            <h3 className="text-3xl font-bold tracking-tight">
              ${user?.balance.toFixed(2)}
            </h3>
          </div>
        </Card>

        <Card>
          <div className="flex items-center gap-4">
            <div className="p-3 bg-green-100 text-green-600 rounded-full">
              <ArrowDownLeft className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Total Spent</p>
              <h4 className="text-xl font-bold text-gray-900">$1,240.50</h4>
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-full">
              <ArrowUpRight className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Labels Created</p>
              <h4 className="text-xl font-bold text-gray-900">42</h4>
            </div>
          </div>
        </Card>
      </div>

      {/* Recent Activity Placeholder */}
      <div className="pt-4">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Recent Activity</h3>
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <div className="p-8 text-center text-gray-500">
            No recent transactions found. Start shipping today!
          </div>
        </div>
      </div>

      <Modal isOpen={isDepositModalOpen} onClose={() => setDepositModalOpen(false)} title="Add Funds via Crypto">
        <div className="space-y-4">
          <p className="text-sm text-gray-600">
            Select cryptocurrency and amount. You will be redirected to NowPayments securely.
          </p>
          <Select 
            label="Cryptocurrency"
            value={currency}
            onChange={(e) => setCurrency(e.target.value)}
            options={[
              { label: 'USDT (Tether)', value: 'USDT' },
              { label: 'Litecoin (LTC)', value: 'LTC' },
              { label: 'Ethereum (ETH)', value: 'ETH' },
              { label: 'DAI', value: 'DAI' }
            ]}
          />
          <Input 
            label="Amount (USD)"
            type="number"
            min="10"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="Min $10.00"
          />
          <div className="pt-2">
            <Button className="w-full" onClick={handleDeposit} loading={loading} disabled={!amount || Number(amount) < 1}>
              Pay with NowPayments
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default Dashboard;