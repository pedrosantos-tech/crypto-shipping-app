import React, { useState, useEffect } from 'react';
import { Copy, Wand2, Truck, AlertCircle, FileCheck } from 'lucide-react';
import { Card, Input, Button, Select } from '../components/Components';
import { useAuth } from '../App';
import { mockCreateLabel, getRandomAddress, mockGetUsedAddresses } from '../services/mockBackend';
import { Address } from '../types';

const CreateLabel: React.FC = () => {
  const { user, refreshUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [usedAddresses, setUsedAddresses] = useState<Address[]>([]);
  
  // Form State
  const [fromAddr, setFromAddr] = useState<Address>({
    name: 'My Store Inc.',
    street1: '123 Warehouse Blvd',
    city: 'Commerce',
    state: 'CA',
    zip: '90040',
    phone: '555-010-9999',
    email: 'shipping@mystore.com'
  });

  const [toAddr, setToAddr] = useState<Address>({
    name: '', street1: '', city: '', state: '', zip: '', phone: '', email: ''
  });

  const [weight, setWeight] = useState<number>(1);
  const [service, setService] = useState('ground');

  useEffect(() => {
    mockGetUsedAddresses().then(setUsedAddresses);
  }, []);

  const handleRandomize = () => {
    setToAddr(getRandomAddress());
  };

  const handleAutocomplete = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selected = usedAddresses.find(a => a.street1 === e.target.value);
    if (selected) {
      setToAddr(selected);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return; // Prevent double submit
    
    setError(null);
    setSuccess(null);
    setLoading(true);

    try {
      const label = await mockCreateLabel({
        from: fromAddr,
        to: toAddr,
        weight,
        service
      });
      await refreshUser();
      setSuccess(`Label created! Tracking: ${label.trackingNumber}`);
      // Clear TO form
      setToAddr({ name: '', street1: '', city: '', state: '', zip: '', phone: '', email: '' });
      // Update autocomplete list
      mockGetUsedAddresses().then(setUsedAddresses);
    } catch (err: any) {
      setError(err.message || 'Failed to create label');
    } finally {
      setLoading(false);
    }
  };

  const AddressForm = ({ title, data, setData, isTo = false }: { title: string, data: Address, setData: (d: Address) => void, isTo?: boolean }) => (
    <Card className="space-y-4">
      <div className="flex justify-between items-center border-b pb-2 mb-2">
        <h3 className="font-semibold text-gray-800">{title}</h3>
        {isTo && (
          <div className="flex gap-2">
             <button type="button" onClick={handleRandomize} className="text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 px-2 py-1 rounded flex items-center">
               <Wand2 className="w-3 h-3 mr-1" /> Random
             </button>
             {usedAddresses.length > 0 && (
               <select 
                 className="text-xs border rounded p-1 max-w-[100px]" 
                 onChange={handleAutocomplete}
                 defaultValue=""
               >
                 <option value="" disabled>Load Saved...</option>
                 {usedAddresses.map((a, i) => (
                   <option key={i} value={a.street1}>{a.name}</option>
                 ))}
               </select>
             )}
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input 
          label="Full Name" 
          value={data.name} 
          onChange={e => setData({...data, name: e.target.value})} 
          required 
        />
        <Input 
          label="Phone" 
          value={data.phone} 
          onChange={e => setData({...data, phone: e.target.value})} 
          required 
        />
      </div>
      <Input 
        label="Street Address" 
        value={data.street1} 
        onChange={e => setData({...data, street1: e.target.value})} 
        required 
      />
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <Input 
          label="City" 
          value={data.city} 
          onChange={e => setData({...data, city: e.target.value})} 
          required 
        />
        <Input 
          label="State" 
          value={data.state} 
          onChange={e => setData({...data, state: e.target.value})} 
          className="uppercase"
          maxLength={2}
          required 
        />
        <div className="col-span-2 md:col-span-1">
          <Input 
            label="ZIP Code" 
            value={data.zip} 
            onChange={e => setData({...data, zip: e.target.value})} 
            required 
          />
        </div>
      </div>
    </Card>
  );

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <h2 className="text-2xl font-bold text-gray-900">Create Shipping Label</h2>
        <div className="text-sm text-gray-500 bg-white px-3 py-1 rounded-full border shadow-sm">
          Balance: <span className={user && user.balance < 10 ? 'text-red-500 font-bold' : 'text-green-600 font-bold'}>
            ${user?.balance.toFixed(2)}
          </span>
        </div>
      </div>

      {success && (
        <div className="p-4 bg-green-50 border border-green-200 text-green-700 rounded-lg flex items-center animate-in slide-in-from-top-2">
          <FileCheck className="w-5 h-5 mr-2" />
          {success}
          <button className="ml-auto underline text-sm" onClick={() => setSuccess(null)}>Close</button>
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg flex items-center animate-in slide-in-from-top-2">
          <AlertCircle className="w-5 h-5 mr-2" />
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <AddressForm title="Ship From" data={fromAddr} setData={setFromAddr} />
          <AddressForm title="Ship To (USA Only)" data={toAddr} setData={setToAddr} isTo />
        </div>

        <Card>
          <h3 className="font-semibold text-gray-800 border-b pb-2 mb-4 flex items-center">
            <Truck className="w-5 h-5 mr-2 text-gray-500" /> Package Details
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Input 
              label="Weight (lbs)" 
              type="number" 
              step="0.1" 
              min="0.1"
              value={weight} 
              onChange={e => setWeight(parseFloat(e.target.value))} 
              required
            />
            <div className="md:col-span-2">
              <Select
                label="Service Level"
                value={service}
                onChange={e => setService(e.target.value)}
                options={[
                  { label: 'Ground (3-5 Days) - $5.00+', value: 'ground' },
                  { label: 'Priority (2-3 Days) - $8.50+', value: 'priority' },
                  { label: 'Express (1-2 Days) - $25.00+', value: 'express' },
                ]}
              />
            </div>
          </div>
        </Card>

        <div className="flex justify-end pt-4">
          <Button type="submit" size="lg" loading={loading} className="w-full md:w-auto min-w-[200px]">
             Purchase Label
          </Button>
        </div>
      </form>
    </div>
  );
};

export default CreateLabel;